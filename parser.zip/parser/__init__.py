# -*- coding: utf-8 -*-

from .model import Model

__all__ = ['Model']
